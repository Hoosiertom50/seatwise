import { NextRequest, NextResponse } from "next/server";
import { getPlanVersionDetail } from "@seatwise/db";
import { getAuthUser } from "@/lib/session";
import { errorResponse } from "@/lib/api-response";
import { requireAccess } from "@/lib/access";

type Params = { params: Promise<{ weddingId: string; planVersionId: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const user = await getAuthUser(req);
  if (!user) return errorResponse("Not authenticated", 401);

  const { weddingId, planVersionId } = await params;
  const access = await requireAccess(weddingId, user.id, "VIEW");
  if ("error" in access) return access.error;

  const planVersion = await getPlanVersionDetail(planVersionId, weddingId);
  if (!planVersion) return errorResponse("Plan version not found", 404);

  return NextResponse.json({ planVersion });
}
